const menuBtn=document.getElementById('menuBtn');
const nav=document.getElementById('nav');
menuBtn.addEventListener('click',()=>nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
document.getElementById('year').textContent=new Date().getFullYear();
const form=document.getElementById('profileForm');
const grid=document.getElementById('profileGrid');
const message=document.getElementById('formMessage');
function initials(name){return name.trim().split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase()}
function addProfile(p){
 const card=document.createElement('article');card.className='profile-card';
 const avatar=document.createElement('div');avatar.className='avatar';avatar.textContent=initials(p.gamer);
 const info=document.createElement('div');const h=document.createElement('h3');h.textContent=p.gamer;
 const game=document.createElement('p');game.textContent=p.game+' • Player';
 const tag=document.createElement('span');tag.className='tag';tag.textContent='COMMUNITY MEMBER';
 info.append(h,game,tag);
 if(p.link){const link=document.createElement('a');link.href=p.link;link.target='_blank';link.rel='noopener noreferrer';link.textContent='Visit creator link';link.style.cssText='display:block;color:#20c8ff;font-size:11px;margin-top:8px';info.append(link)}
 card.append(avatar,info);grid.append(card);
}
try{JSON.parse(localStorage.getItem('darknovaProfiles')||'[]').forEach(addProfile)}catch(e){}
form.addEventListener('submit',e=>{
 e.preventDefault();const data=new FormData(form);
 const p={gamer:String(data.get('gamer')).trim(),game:String(data.get('game')).trim(),link:String(data.get('link')).trim()};
 if(p.link&&!/^https?:\/\//i.test(p.link)){message.textContent='Please enter a full link beginning with https://';return}
 const profiles=JSON.parse(localStorage.getItem('darknovaProfiles')||'[]');
 if(profiles.length>=10){message.textContent='Demo limit reached (10 profiles on this device).';return}
 profiles.push(p);localStorage.setItem('darknovaProfiles',JSON.stringify(profiles));addProfile(p);
 form.reset();message.textContent='Profile added on this device!';
});
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))}
