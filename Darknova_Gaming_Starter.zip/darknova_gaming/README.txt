DARKNOVA GAMING — STARTER WEBSITE

Included:
- Responsive dark/neon-blue gaming community landing page
- Sample Darknova player profile
- Demo profile creation stored in the current browser/device only
- PWA manifest and service worker for installability/offline shell

IMPORTANT LIMITATIONS:
- This is a front-end starter, not a production community backend.
- Profiles are stored only in localStorage on the visitor's device. They are NOT shared with other visitors.
- There is no account login, password system, database, chat, moderation dashboard or cloud upload.
- Do not collect passwords or sensitive personal information in this demo.
- For a real public community, add a secure backend/database, authentication, moderation and privacy policy.

HOW TO PREVIEW:
1. Extract the ZIP.
2. Open index.html in a browser for a basic preview.
3. For PWA install/service-worker testing, deploy the folder to an HTTPS static host (for example GitHub Pages or Cloudflare Pages).
4. Open the deployed HTTPS URL in Chrome on Android, then use browser menu > Install app / Add to Home screen (wording may vary).

CUSTOMIZE:
- Edit index.html for text and sections.
- Edit styles.css for colors and layout.
- Edit app.js for demo profile behavior.
- Change manifest.webmanifest for app name and icons.

BUDGET NOTE:
This starter can be hosted on a free static hosting tier with a custom domain purchased separately. Check current domain and hosting prices before paying.


BRAND: DARKNOVA GAMING
Theme: Black + Neon Blue
This is a renamed and branded starter build.
